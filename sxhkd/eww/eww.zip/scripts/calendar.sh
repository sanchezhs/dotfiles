#!/bin/sh

month=$(date +%m)
month=$((month-1)) # for some reason eww gives the month as a zero-based integer

echo $month